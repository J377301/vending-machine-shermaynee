// vvendingmachine.cpp : Defines the entry point for the console application.
//Vending Maching Program created by Shermayne Ziqing Lee

#include "stdafx.h"
#include <iostream>;
#include <string>
using namespace std;

//Declare variables for the used of program
int NextPurchase;
double change;
double MoneyInsert;
int ChoiceOfProduct;
int Product_Array_Size = 10;
string NameOfProduct;
//Array for vending maching product and price of products 
string products[10] = { "1.Popcorn","2.TeddyBiscuit", "3.Pretzel","4.MintBar","5.VegeChips", "6.RiceCracker","7.SourCream&Chives","8.ChocolotaChipsMuseli","9.BerryMuseli","10.LeSnakCheddarCheese" };
double productsPrices[10] = { 2.0,4.5,5.0,2.0,2.5,3.0,3.5,4.0,4.0,2.0 };
int StockOfProducts[10] = {10,10,10,10,10,10,10,10,10,10};
bool continue_;

int main()
{

	//Begining of main loop 
	do
	{
		//To make sure user can have few purchase before quiting the program 
		continue_ = true;
		cout << "/////////////////////////////////////////\n"
			"/////////////////////////////////////////\n"
			"////////////////////////////////////////\n"
			"//WELCOME TO DELICIOUS VENDING MACHINE!!//\n"
			"////////////////////////////////////////\n"
			"///////////////////////////////////////\n"
			"///////////////////////////////////////\n";

		//Binary search to allow user continue or quit the program
		int binarysearch;
		cout << "Please enter 1 if you wish to continue else enter 2!\n";
		cin >> binarysearch;

		if (binarysearch == 1)
		{
			//Sequential access in the menu of products	
			//For loop to display all the data of products
			for (int i = 0; i < Product_Array_Size; i++)
			{
				cout << products[i] << "	Price $:" << productsPrices[i] << "		Products Left:	" << StockOfProducts[i] << "\n";

			}


			cout << "Please select the products you would like to purchase from the menu!!\n"
				"Enter the number written beside the prodct.\n"
				<< endl;

			//Random access for the menu of prouct in vending machine
			//Allow user to choose product
			cin >> ChoiceOfProduct;

			if (ChoiceOfProduct == 0)
			{
				cout << "Thanks and Have a nice day!";

			}

			else if (ChoiceOfProduct >= 10 || ChoiceOfProduct < 0)
			{
				cout << "Please enter the number written beside the products!";
				
			}
			else
			{
			
				cout << " This is the product you have chosen " << products[ChoiceOfProduct - 1] << "\n";

				//pointer to get the number of stocks in the array
				int *pStockofProduct = StockOfProducts;
				int i = ChoiceOfProduct - 1;
				int newStockValue[10];
				newStockValue[i] = pStockofProduct[i] - 1;
				//Update existing array with new stock number
				StockOfProducts[i] = newStockValue[i];
				cout << "The amount of  " << products[ChoiceOfProduct - 1] << "	left in vending machine " << newStockValue[i] << "\n";
				cout << "Please insert this amount of money " << productsPrices[ChoiceOfProduct - 1] << "\n";
			}

			//Allow vending machine to accept money from user 
			cout << "Amount of money you wish to insert?\n";
			cin >> MoneyInsert;

			//Deletion in array
			if (MoneyInsert < productsPrices[ChoiceOfProduct - 1])
			{
				cout << "Please insert adequate money for the product?\n";
				
			}
			else if (MoneyInsert > productsPrices[ChoiceOfProduct - 1])
			{
				change = MoneyInsert - productsPrices[ChoiceOfProduct - 1];
				cout << "Please take your change $:" << change << "\n";
				cout << "Thank  you!\n";
				
			}
			else
			{
				cout << "Thank you and have a nice day!\n";
				
			}

			//Deletion and Insertion
			cout << "Press 1 if you wish to purchase another product";
			cin >> NextPurchase;
			if (NextPurchase == 1)
			{
				continue_ == true;
			}
			
		}
		else
		{
			cout << "Please only type number 1 or 2!";
			
		}

	} while (continue_ == true);
}

